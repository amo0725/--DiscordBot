const Config ={
    db : {
        hostname: 'us-cdbr-east-03.cleardb.com',
        user: 'b61d1f6a573d6b',
        password:'9fc60090',
        database: 'heroku_84cfacb2231b5fd'
    },

    client : {
        token : 'ODM1OTA1MDI1ODQxNjkyNzEz.YIWPOA.UBZ5NnX6H2zukRpwhmrVRbTqPYg'
    }
}

module.exports = Config;