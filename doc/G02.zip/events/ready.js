module.exports = (Discord, client) =>{
    console.log(`${client.user.tag} 已上線 !`);
}